/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Pac
 */
abstract public class Human extends Player {
    @Override
    void humanMove(int h, int move){
    //add move code
    }
    void humanMark(int h, int mark){
    //add move code
    } 
    
}
